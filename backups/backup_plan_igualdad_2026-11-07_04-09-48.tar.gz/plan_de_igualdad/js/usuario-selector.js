// persona usuaria-selector.js - Rellena el selector de persona usuaria en la cabecera

document.addEventListener('DOMContentLoaded', () => {
    const select = document.getElementById('persona usuariaActualSelect');
    if (!select) return;

    const comite = MODELO.getComite();
    const actual = MODELO.getPersona usuariaActual();

    select.innerHTML = '<option value="">— Selecciona —</option>';

    // Función auxiliar para añadir persona integrantes
    const agregarPersona integrantes = (lista, bando) => {
        lista.forEach(m => {
            if (!m.nombre) return;
            const opt = document.createElement('option');
            opt.value = m.nombre;
            opt.textContent = `${m.nombre} (${m.rol})`;
            if (m.nombre === actual) opt.selected = true;
            select.appendChild(opt);
        });
    };

    if (comite.empresa.length === 0 && comite.trabajadoras y trabajadores.length === 0) {
        const opt = document.createElement('option');
        opt.value = '';
        opt.textContent = '⚠️ Configura el comité primero';
        opt.disabled = true;
        select.appendChild(opt);
    } else {
        agregarPersona integrantes(comite.empresa);
        agregarPersona integrantes(comite.trabajadoras y trabajadores);
    }

    select.addEventListener('change', (e) => {
        MODELO.setPersona usuariaActual(e.target.value);
    });
});
